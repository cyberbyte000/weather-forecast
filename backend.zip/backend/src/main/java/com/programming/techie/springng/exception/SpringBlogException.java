package com.programming.techie.springng.exception;

public class SpringBlogException extends RuntimeException {
    public SpringBlogException(String message) {
        super(message);
    }
}
